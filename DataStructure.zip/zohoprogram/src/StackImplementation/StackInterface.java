package StackImplementation;

interface StackInterface {
	
	void myPush(int element);
	int myPop();
	int myPeek();
	int mySize();
	boolean myEmpty();
	int myCapacity();
	int myRemainCapacity();
	int[] display();
}
