package StackImplementation;
import java.util.Arrays;

import StackImplementation.StackMethods;

//Time complicity o(1)
public class StackController {

	public static void main(String[] args) {
		StackMethods stm = new StackMethods();
		
		
		stm.myPush(10);
		System.out.println(stm.myPeek());
		System.out.println("Stack Is Empty : "+stm.myEmpty());
		stm.myPop();
		System.out.println(stm.myPeek());
		}
	}


