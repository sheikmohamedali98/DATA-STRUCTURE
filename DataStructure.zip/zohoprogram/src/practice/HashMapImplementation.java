package practice;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

public class HashMapImplementation<K,V> {

	private int CAPACITY = 16;
	    private MapBucket[] bucket;
	    private int size = 0;
	    ArrayList<Object> list = new ArrayList<>();
	    private float loadFactor = 0.75f;
	    private float threshold = CAPACITY*loadFactor;

	    public HashMapImplementation() {
	        this.bucket = new MapBucket[CAPACITY];
	    }
	    private int getHash(K key) {
	        return (key.hashCode() & 0xfffffff) % CAPACITY;
	    }

	    @SuppressWarnings("unchecked")
	    private Node<K,V> getEntry(K key) {
	        int hash = getHash(key);
	        for (int i = 0; i < bucket[hash].getEntries().size(); i++) {
	            Node<K,V> myKeyValueEntry = bucket[hash].getEntries().get(i);
	            if(myKeyValueEntry.getKey().equals(key)) {
	                return myKeyValueEntry;
	            }
	        }
	        return null;
	    }
	    
	    public void put(K key, V value) {
	        if(containsKey(key)) {
	           
				Node<K,V> entry = getEntry(key);
	            entry.setValue(value);
	            list.add(value);
	        } else {
	            int hash = getHash(key);
	            if(bucket[hash] == null) {
	                bucket[hash] = new MapBucket();
	            }
	            bucket[hash].addEntry(new Node<>(key, value));
	            list.add(value);
	            size++;
	        }
	    }

	    public V get(K key) {
	        return containsKey(key) ? (V) getEntry(key).getValue() : null;
	    }
	    public K getKey(V Value){
	    	
			return null;
	    	
	    }

	    public boolean containsKey(K key) {
	        int hash = getHash(key);
	        return !(Objects.isNull(bucket[hash]) || Objects.isNull(getEntry(key)));
	    }

	    public void delete(K key) {
	        if(containsKey(key)) {
	            int hash = getHash(key);
	            bucket[hash].removeEntry(getEntry(key));
	            list.remove(key);
	           // bucket[hash] = null;
//	            size--;
	        }
//	    	MapBucket[] tab;
//	    	if((tab=bucket)!=null&&size>0){
//		    	   size--;
////	    	tab = bucket;
//		    	  for(int i=0;i<tab.length;i++){
//		    		  if(tab[i]==key){
//		    			  tab[i] = null;
//		    			 
//		    		  }
//		    	  }
//	    	}
	    }
	    

	    public void clear(){
	       MapBucket[] tab = bucket;
	       if((tab)!=null&&size>0){
	    	   size = 0;
	    	   for(int i =0;i<tab.length;i++){
	    		   tab[i] = null;
	    	   }
	       }
	    }
	    
	    private void resize() {
			if (size == CAPACITY) {
				CAPACITY = CAPACITY + (CAPACITY >> 1);
				MapBucket[] newArray = new MapBucket[CAPACITY];
				for (int i = 0; i < size; i++) {
					newArray[i] = bucket[i];
				}
				this.bucket = newArray;
			}
		}
	    
	    
	    public int count(V value){
	    	 int count = 0;
	    	 for(Object obj:list){
	    		 if(obj == value){
	    			 count++;
	    		 }
	    	 }
	      return count;
	    }
	    
	    
	    public void putAll(HashMapImplementation<K,V> m) {
	        putMapEntries(m, true);
	    }
	    final void putMapEntries(HashMapImplementation<K,V> map, boolean flag) {
	        int s = map.size();
	        if (s > 0) {
	            if (bucket == null) { // pre-size
	                float ft = ((float)s / loadFactor) + 1.0F;
	                int t = ((ft < (float)CAPACITY) ?
	                         (int)ft : CAPACITY);
	                if (t > threshold)
	                    threshold = bucket.length;
	            } else {
	                // Because of linked-list bucket constraints, we cannot
	                // expand all at once, but can reduce total resize
	                // effort by repeated doubling now vs later
	                while (s > threshold && bucket.length < CAPACITY)
	                    resize();
	            }

	            for (HashMapImplementation.Node<K,V> e : map.entrySet()) {
	                K key = e.getKey();
	                V value = e.getValue();
	                put(key,value);
	            }
	        }
	    }
	   
		public int size() {
	        return size;
	    }
		
	}

