package practice;
import java.util.LinkedList;
import java.util.List;
import practice.Node;
@SuppressWarnings("rawtypes")
public class MapBucket {
	   
		private List<Node> entries;

	    public MapBucket() {
	        if(entries == null) {
	            entries = new LinkedList<>();
	        }
	    }

		public List<Node> getEntries() {
	        return entries;
	    }

	    public void addEntry(Node entry) {
	        this.entries.add(entry);
	    }

	    public void removeEntry(Node entry) {
	        this.entries.remove(entry);
	    }
	    
	}

