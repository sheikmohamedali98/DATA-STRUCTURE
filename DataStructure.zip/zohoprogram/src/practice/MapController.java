package practice;


public class MapController {
    public static void main(String[] args) {
    	HashMapImplementation<Integer,Integer> myMap = new HashMapImplementation<Integer,Integer> ();
        myMap.put(1,20);
        myMap.put(2,30);
        myMap.put(3,40);
        myMap.put(4, 50);
        myMap.put(5, 55);
        System.out.println(myMap.count(50));
        System.out.println(myMap.size());
        System.out.println(myMap.containsKey(1));
        myMap.delete(2);
      //System.out.println(myMap.count(40));
       // myMap.clear();
//    	HashMapImplementation<Integer,Integer> myMap1 = new HashMapImplementation<Integer,Integer> ();
//    	   myMap.put(6,40);
//           myMap.put(7, 50);
//           myMap.put(8, 55);
//        
//           myMap.putAll(myMap1);
//        System.out.println(myMap.count(50));
        for (int i = 1; i <= myMap.size(); i++) {
            System.out.println(myMap.get(i));
        }
         System.out.println(myMap.size());
//        for (int i = 1; i <= myMap.size(); i++) {
//            System.out.println(myMap.get(i));
//            System.out.println("hai");
//        }
    }
}

