package Task5;


	

	public class Node<K, V> {
		
		final K key;
		V value;
		Node<K, V> next;
		
		public  Node(K key,V value) {
			this.key = key;
			this.value = value;
			this.next = null;
		}

	

}
