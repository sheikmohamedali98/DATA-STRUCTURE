package Task5;

import java.util.ArrayList;

import Task5.Node;


public class MapImplementation<K, V>  {
	private  int size;
	Node<K,V> head;
	ArrayList<Object> list = new ArrayList<>();
	MapImplementation(){
		this.size = 0;
		
		
	}
	

	public void put(K key, V value) {
		Node<K,V> newnode =  new Node<K,V>(key,value);
		if (head == null) {
			head = newnode;
			size++;
		} 
		else {
			Node<K,V> temp =  new Node<K,V>(key,value);

			while (temp.next != null) {
				if (temp.key.equals(key)) {
					temp.value = value;
					list.add(value);
				}
				temp = temp.next;
			}
			//if already existing
			if (temp.key.equals(key)) {
				temp.value = value;
			} else {
				temp.next =  newnode;
				size++;
			}
		}
	}
	
	public void display(){
		Node<K,V> ptr = head;
		if(ptr == null){
			System.out.println("map is empty");
		}
		while(ptr!= null){
			System.out.print(ptr.key + " "+ptr.value+" ");
			ptr = ptr.next;
		}
		System.out.println();
	}

	public int count(V value) {
		Node<K,V> temp = head;
		int count = 0;
		while (temp.next != null) {
			if (temp.value.equals(value)) {
				count++;
			}
			temp = temp.next;
			
		}
		if (temp.value.equals(value)) {
			count++;
		}

		return count;
	}

	public boolean isEmpty() {
		if (head == null) {
			return true;
		}
		return false;
	}

	public V get(K key) {
		V value = null;
		while (head.next != null) {
			if (head.key.equals(key)) {
				value = head.value;

			}

			return value;
		}
		value = head.value;
		return value;

	}

	public void replace(K key, V value) {
		while (head.next != null) {
			if (head.key.equals(key)) {
				head.value = value;

			}
		}
		if (head.key.equals(key)) {
			head.value = value;
		}

	}

	public boolean remove(K key) {
		Node<K,V> temp = head;
		while (temp.next != null) {
			if (temp.key.equals(key)) {
				// head.value = null;
				// head.key = null;
				temp = null;
				size--;
				return true;

			}
			temp = temp.next;
		}
		if (temp.key.equals(key)) {
			temp.next = null;
			size--;
			return true;
		}
		return false;

	}

	public boolean clear() {
		while (head.next != null) {
			head = null;
			size--;
		}
		head = null;
		return false;

	}

	public Node<K, V> mergeTwoLists(Node<K, V> list1, Node<K, V> list2) {
		K key = null;
		V value = null;
		Node<K, V> start = new Node<K, V>(key,value);
		Node<K, V> temp = start;

		if (list1.next != null) {
			start.next = list1;
		}
		if (list2.next != null) {
			start.next = list2;
		}
		return temp.next;

	}

	@SuppressWarnings({ "null", "unchecked" })
	public MapImplementation<K, V> putAll(MapImplementation<K, V> map1,MapImplementation<K, V> map2) {

		// Node<K, V> temp = null;
		// Node<K, V> end = temp.next;
		// System.out.println("merge method");

		MapImplementation<K, V> temp = null;

		if (temp.head.next == null) {
          while(head.next!=null){
			temp.head.next = map1.head;
          }

		}
		if (temp.head.next == null) {

			temp.head.next = map2.head;

		}

		map1 = temp;
		return map1;
	}
	public boolean putAll(MapImplementation<K, V> map1){
		if(head.next == null){
			head.next = map1.head;
		}
		return false;
	}

	public String toString() {
		Node<K, V> temp = head;
		StringBuilder br = new StringBuilder();
		br.append("[");
		br.append(temp.key + "  " + temp.value + ";");
		while (temp.next != null) {
			temp = temp.next;
			br.append(temp.key + "  " + temp.value + ";");
			
		}
		//br.deleteCharAt(br.length() - 1);
		br.append("]");
		return br.toString();
	}

}
