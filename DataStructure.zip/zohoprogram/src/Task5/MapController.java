package Task5;

public class MapController{
	public static void main(String[] args){
		MapImplementation<Integer,Integer> map = new MapImplementation<Integer,Integer>();
		map.put(1, 30);
		map.put(2, 40);
		
		map.put(3, 50);
		map.put(4, 60);
		map.put(1, 35);
		map.put(2, 45);
		map.put(3, 55);
		System.out.println(map.toString());
		
		

		
	}
}